import React from "react";

export default function Header(props) {
  return (
    <div className="navbar--container">
      <div className="middle--container">
        <span className="nav--p">나의 여행 일지</span>
      </div>
    </div>
  );
}
